// Menú móvil
const burgerBtn = document.getElementById('burgerBtn');
const mobileLinks = document.getElementById('mobileLinks');

if (burgerBtn && mobileLinks) {
  burgerBtn.addEventListener('click', () => {
    mobileLinks.classList.toggle('open');
  });

  // Cerrar el menú al elegir una sección
  mobileLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => mobileLinks.classList.remove('open'));
  });
}

// Formulario de contacto: envío AJAX a Netlify Forms sin redireccionar a /contacto.
const contactForm = document.getElementById('contactForm');
const formSuccess = document.getElementById('formSuccess');

if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const submitButton = contactForm.querySelector('button[type="submit"]');
    const originalText = submitButton ? submitButton.textContent : '';
    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = 'Enviando...';
    }

    try {
      const formData = new FormData(contactForm);
      const response = await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(formData).toString()
      });

      if (!response.ok) throw new Error(`HTTP ${response.status}`);

      contactForm.reset();
      if (formSuccess) formSuccess.hidden = false;
      if (formSuccess) formSuccess.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (error) {
      alert('No pudimos enviar la consulta. Por favor, intentá nuevamente.');
    } finally {
      if (submitButton) {
        submitButton.disabled = false;
        submitButton.textContent = originalText;
      }
    }
  });
}

// Newsletter (mockup)
const newsletterForm = document.getElementById('newsletterForm');
if (newsletterForm) {
  newsletterForm.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('¡Gracias por suscribirte!');
    newsletterForm.reset();
  });
}

// Carrusel de fotos del hero (home)
const heroCarousel = document.getElementById('heroCarousel');
if (heroCarousel) {
  const heroSection = heroCarousel.closest('.hero-new');
  const slides = heroCarousel.querySelectorAll('.hero-slide');
  const dots = heroSection.querySelectorAll('.dot');
  const prevBtn = heroSection.querySelector('.hero-carousel-arrow.prev');
  const nextBtn = heroSection.querySelector('.hero-carousel-arrow.next');
  let current = 0;
  let autoTimer;

  function goTo(index) {
    slides[current].classList.remove('active');
    dots[current].classList.remove('active');
    current = (index + slides.length) % slides.length;
    slides[current].classList.add('active');
    dots[current].classList.add('active');
  }

  function restartAuto() {
    clearInterval(autoTimer);
    autoTimer = setInterval(() => goTo(current + 1), 6000);
  }

  if (prevBtn && nextBtn) {
    prevBtn.addEventListener('click', () => { goTo(current - 1); restartAuto(); });
    nextBtn.addEventListener('click', () => { goTo(current + 1); restartAuto(); });
  }
  dots.forEach((dot, i) => {
    dot.addEventListener('click', () => { goTo(i); restartAuto(); });
  });

  restartAuto();
}
