# EOLIK — Sitio web multipágina

Estructura del proyecto, lista para abrir en VS Code:

```
eolik-site/
├── index.html               → Inicio
├── nuestra-empresa.html     → Nuestra empresa
├── productos.html           → Catálogo completo (difusores, rejas, persianas, dampers, soportería)
├── obras-realizadas.html    → Galería de obras / proceso de fabricación
├── servicios.html           → Servicios que ofrece EOLIK
├── contacto.html            → Datos de contacto + formulario + mapa
├── css/style.css            → Toda la hoja de estilos (paleta, tipografía, layout, responsive)
├── js/script.js             → Menú móvil + formularios de ejemplo
├── img/                     → Fotos usadas, extraídas del catálogo EOLIK
└── README.md
```

## Cómo verlo
Abrí `index.html` en el navegador, o en VS Code instalá la extensión
**Live Server** y hacé clic derecho sobre `index.html` →
"Open with Live Server" para navegar entre páginas con recarga
automática mientras editás.

## Navegación
El menú de arriba (y el del pie de página) enlaza a cada página real
—no son anclas dentro de una sola página—, igual que en sccordoba.com.ar:
Inicio, Nuestra empresa, Productos, Obras realizadas, Servicios y
Contacto son archivos `.html` separados.

Dentro de `productos.html` sí hay anclas internas (Difusores, Rejas,
Persianas, Dampers, Soportería) para saltar a cada categoría sin
salir de la página, con toda la info tal como figura en el catálogo:
descripción, material, acabado superficial, opcionales y dimensiones
estándar.

## Qué reemplazar antes de publicarlo
- **Obras realizadas**: hoy usa fotos de fabricación en planta y una
  instalación de ejemplo. Reemplazar por fotos reales de obras
  terminadas en clientes, agrupadas por nombre de proyecto.
- **Fotos de productos**: cada producto ya tiene su propia foto real
  (extraída del catálogo, con fondo gris parejo). Si quieren
  reemplazar alguna, se edita directamente en `productos.html`
  (buscar el bloque `<img src="img/...">` correspondiente) y se
  reemplaza el archivo en `img/`.
- **Formulario de contacto**: preparado para **Netlify Forms**. Al publicar el sitio en Netlify, las consultas se registrarán automáticamente y se puede activar una notificación al email de la empresa desde el panel de Netlify.
- **Newsletter**: sigue siendo de ejemplo y todavía no está conectado a un servicio de suscripciones.
- **Servicios**: la lista de 6 servicios es una propuesta razonable
  a partir de lo que dice el catálogo (asesoramiento técnico,
  fabricación a medida, acabados, automatización, entrega,
  posventa). Conviene revisarla con la empresa y ajustar si hace
  falta.
- **Logo**: se usa un logotipo de texto simple. Si tienen el logo en
  vector (SVG) o alta resolución, reemplazar el texto `.brand` del
  header y el footer por la imagen real.

## Paleta usada (variables CSS en `style.css`)
- `--navy:  #132238` (azul oscuro — headers, footer, textos fuertes)
- `--slate: #4e5a76` (azul apagado — textos secundarios)
- `--blue:  #5170ff` (azul intenso — acentos, botones, links)
- `--white: #ffffff`
- `--ink:   #1a1f29` (negro suave para texto de cuerpo)
